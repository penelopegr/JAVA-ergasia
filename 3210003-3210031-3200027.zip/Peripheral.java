abstract class Peripheral extends Product {
    double finalPrice;
    double fdiscRate = .25;
    String discRate = "10%";

    // Constructor
    public Peripheral(String model, String model_year, String manufacturer, Double price, int stock) {
        super(model, model_year, manufacturer, price, stock);
        this.finalPrice = price * (1 - fdiscRate);
    }

    public double getFinalPrice() {
        return finalPrice;
    }

}